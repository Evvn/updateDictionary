let Airtable = require('airtable')
require('dotenv').config()
// rate(1 minute)
// ap-southeast-2

let API_KEY = process.env.REACT_APP_AIRTABLE_API_KEY

Airtable.configure({apiKey: API_KEY, endpointUrl: 'https://api.airtable.com'})

let base = new Airtable({apiKey: API_KEY}).base('appHNmzsbpQLZtgte');

base('CRONTEST').create({
  "Name": "ｎｅｗ　ｒｅｃｏｒｄ　ょ圧ゼ"
}, function(err, record) {
    if (err) { console.error(err); return; }
});
